/* config.h - Libexif configuration file for HarmonyOS */

/* Define if you have the stddef.h header file. */
#define HAVE_STDDEF_H 1

/* Define if you have the stdlib.h header file. */
#define HAVE_STDLIB_H 1

/* Define if you have the string.h header file. */
#define HAVE_STRING_H 1

/* Define if you have the sys/types.h header file. */
#define HAVE_SYS_TYPES_H 1

/* Define if you have the unistd.h header file. */
#define HAVE_UNISTD_H 1

/* Define if you have the limits.h header file. */
#define HAVE_LIMITS_H 1

/* Define if you have the fcntl.h header file. */
#define HAVE_FCNTL_H 1

/* Define to 1 if you have the inttypes.h header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the stdint.h header file. */
#define HAVE_STDINT_H 1

/* Define if you have the inline keyword. */
#define HAVE_INLINE 1

/* Define if you have the __inline keyword. */
#define HAVE___INLINE 1

/* Define if you have the __inline__ keyword. */
#define HAVE___INLINE__ 1

/* Define to 1 if you have the strtol function. */
#define HAVE_STRTOL 1

/* Define to 1 if you have the strtoul function. */
#define HAVE_STRTOUL 1

/* Define to 1 if you have the snprintf function. */
#define HAVE_SNPRINTF 1

/* Define to 1 if you have the vsnprintf function. */
#define HAVE_VSNPRINTF 1

/* Define to 1 if you have the snprintf function. */
#define HAVE__SNPRINTF 1

/* Define to 1 if you have the vsnprintf function. */
#define HAVE__VSNPRINTF 1

/* Define to 1 if you have the memcpy function. */
#define HAVE_MEMCPY 1

/* Define to 1 if you have the memmove function. */
#define HAVE_MEMMOVE 1

/* Define to 1 if you have the strchr function. */
#define HAVE_STRCHR 1

/* Define to 1 if you have the strdup function. */
#define HAVE_STRDUP 1

/* Define to 1 if you have the strrchr function. */
#define HAVE_STRRCHR 1

/* Define to 1 if you have the strstr function. */
#define HAVE_STRSTR 1

/* Define to 1 if you have the strtol function. */
#define HAVE_STRTOL 1

/* Define to 1 if you have the strtoul function. */
#define HAVE_STRTOUL 1

/* Define to 1 if you have the strtoull function. */
#define HAVE_STRTOULL 1

/* Define to 1 if you have the getenv function. */
#define HAVE_GETENV 1

/* Define to 1 if you have the setenv function. */
#define HAVE_SETENV 1

/* Define to 1 if you have the unsetenv function. */
#define HAVE_UNSETENV 1

/* Define to 1 if you have the pow function. */
#define HAVE_POW 1

/* Define to 1 if you have the powf function. */
#define HAVE_POWF 1

/* Define to 1 if you have the floor function. */
#define HAVE_FLOOR 1

/* Define to 1 if you have the floorf function. */
#define HAVE_FLOORF 1

/* Define to 1 if you have the round function. */
#define HAVE_ROUND 1

/* Define to 1 if you have the roundf function. */
#define HAVE_ROUNDF 1

/* NOTE: Do NOT define ENABLE_NLS - libexif uses #ifdef not #if */

/* i18n macros - needed when ENABLE_NLS is not defined */
/* Some source files call bindtextdomain() directly, so we need these */
#define GETTEXT_PACKAGE "libexif"
#define LOCALEDIR "/usr/share/locale"

/* Package information */
#define PACKAGE "libexif"
#define VERSION "0.6.26.1"
#define PACKAGE_NAME "libexif"
#define PACKAGE_VERSION "0.6.26.1"

/* Enable large file support */
#define _FILE_OFFSET_BITS 64
#define _LARGEFILE64_SOURCE 1

/* Define to empty if the keyword does not work. */
#define const
