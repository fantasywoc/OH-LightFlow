/* _stdint.h - Libexif stdint compatibility header */

#ifndef LIBEXIF_STDINT_H
#define LIBEXIF_STDINT_H

#include <stdint.h>

#endif /* LIBEXIF_STDINT_H */
